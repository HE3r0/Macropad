import board
import busio
import displayio
import terminalio
import time
import os
import sys
import rotaryio
import digitalio
import usb_hid

from displayio import OnDiskBitmap
from i2cdisplaybus import I2CDisplayBus
from adafruit_debouncer import Debouncer
from adafruit_display_text import label
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode
import adafruit_displayio_sh1106


KEYMAP_DIR = "KeyMaps"
STATUS_FILE = "status.cfg"
FW_VERSION = "0.6"
DISPLAY_IDLE_SECONDS = 5 * 60  # x times seconds = total minutes
display_asleep = False


keyboard = Keyboard(usb_hid.devices)
consumer = ConsumerControl(usb_hid.devices)

# =================================================
# State
# =================================================

profiles = []
active_index = None
last_profile_name = ""

menu_mode = False
menu_level = "root"   # root, settings, about, keytest
menu_index = 0
status_until = 0.0

default_status = "Ready"

keytest_last_event = "Press a key"
keytest_exit_hint = "Push encoder to exit"

last_activity = time.monotonic()
display_asleep = False


# =================================================
# OLED
# =================================================

displayio.release_displays()

i2c = busio.I2C(board.GP1, board.GP0)  # SCL, SDA
display_bus = I2CDisplayBus(i2c, device_address=0x3C)

display = adafruit_displayio_sh1106.SH1106(
    display_bus,
    width=132,
    height=64,
    rotation=0,
)

root = displayio.Group()
display.root_group = root

main_title_group = displayio.Group(scale=2, x=8, y=10)
main_title = label.Label(
    terminalio.FONT,
    text="KeyMaps",
    color=0xFFFFFF,
    x=0,
    y=0,
)
main_title_group.append(main_title)
root.append(main_title_group)

main_status = label.Label(
    terminalio.FONT,
    text="Loading...",
    color=0xFFFFFF,
    x=8,
    y=34,
)
root.append(main_status)

menu_title = label.Label(
    terminalio.FONT,
    text="",
    color=0xFFFFFF,
    x=8,
    y=10,
)
root.append(menu_title)

menu_line1 = label.Label(
    terminalio.FONT,
    text="",
    color=0xFFFFFF,
    x=8,
    y=26,
)
menu_line2 = label.Label(
    terminalio.FONT,
    text="",
    color=0xFFFFFF,
    x=8,
    y=40,
)
menu_line3 = label.Label(
    terminalio.FONT,
    text="",
    color=0xFFFFFF,
    x=8,
    y=54,
)
root.append(menu_line1)
root.append(menu_line2)
root.append(menu_line3)


def clear_all_labels():
    main_title.text = ""
    main_status.text = ""
    menu_title.text = ""
    menu_line1.text = ""
    menu_line2.text = ""
    menu_line3.text = ""




def show_temporary(message, seconds=0.8):
    global status_until
    print(message)
    main_status.text = message[:20]
    status_until = time.monotonic() + seconds


def set_root_row_layout():
    menu_line1.y = 10
    menu_line2.y = 26
    menu_line3.y = 42


def set_titled_row_layout():
    menu_line1.y = 26
    menu_line2.y = 40
    menu_line3.y = 54


def note_activity():
    global last_activity
    last_activity = time.monotonic()


def wake_display():
    global display_asleep
    if display_asleep:
        try:
            display.wake()
        except AttributeError:
            pass
        display_asleep = False
        redraw()


def sleep_display_if_idle():
    global display_asleep

    if display_asleep:
        return

    if time.monotonic() - last_activity >= DISPLAY_IDLE_SECONDS:
        clear_all_labels()
        display_asleep = True


def wake_display():
    global display_asleep
    if display_asleep:
        display_asleep = False
        redraw()


def show_splash():
    clear_all_labels()

    try:
        splash = OnDiskBitmap("/splash.bmp")

        tile = displayio.TileGrid(
            splash,
            pixel_shader=splash.pixel_shader
        )

        group = displayio.Group()
        group.append(tile)

        display.root_group = group

        time.sleep(1.5)

        display.root_group = root

    except Exception as exc:
        print("Splash load failed:", exc)

        main_title.text = "MACROPAD"
        main_status.text = "Booting..."
        time.sleep(1.5)



# =================================================
# Status file
# =================================================

def load_status():
    global last_profile_name
    last_profile_name = ""

    try:
        with open(STATUS_FILE, "r") as fp:
            for raw in fp:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip().upper()
                value = value.strip()

                if key == "LAST_PROFILE":
                    last_profile_name = value
    except OSError:
        pass


def save_status():
    profile = current_profile()
    profile_name = profile["name"] if profile else ""

    try:
        with open(STATUS_FILE, "w") as fp:
            fp.write("LAST_PROFILE={}\n".format(profile_name))
        print("Status saved")
    except OSError:
        pass


def persist_last_profile():
    save_status()


# =================================================
# Helpers: key parsing and execution
# =================================================

def normalize_token(token):
    token = token.strip().upper()

    aliases = {
    # ==========================================
    # Control keys
    # ==========================================
    "CTRL": "CONTROL",
    "CONTROL": "CONTROL",
    "LCTRL": "LEFT_CONTROL",
    "RCTRL": "RIGHT_CONTROL",

    "ALT": "ALT",
    "LALT": "LEFT_ALT",
    "RALT": "RIGHT_ALT",

    "SHIFT": "SHIFT",
    "LSHIFT": "LEFT_SHIFT",
    "RSHIFT": "RIGHT_SHIFT",

    "WIN": "GUI",
    "GUI": "GUI",
    "CMD": "GUI",
    "COMMAND": "GUI",
    "SUPER": "GUI",

    "LWIN": "LEFT_GUI",
    "RWIN": "RIGHT_GUI",

    # ==========================================
    # Enter / Escape / Editing
    # ==========================================
    "ESC": "ESCAPE",
    "ESCAPE": "ESCAPE",

    "ENTER": "ENTER",
    "RETURN": "ENTER",

    "TAB": "TAB",

    "DEL": "DELETE",
    "DELETE": "DELETE",

    "BKSP": "BACKSPACE",
    "BACKSPACE": "BACKSPACE",

    "INS": "INSERT",
    "INSERT": "INSERT",

    "SPACE": "SPACEBAR",

    # ==========================================
    # Navigation
    # ==========================================
    "UP": "UP_ARROW",
    "DOWN": "DOWN_ARROW",
    "LEFT": "LEFT_ARROW",
    "RIGHT": "RIGHT_ARROW",

    "HOME": "HOME",
    "END": "END",

    "PGUP": "PAGE_UP",
    "PAGEUP": "PAGE_UP",

    "PGDN": "PAGE_DOWN",
    "PAGEDOWN": "PAGE_DOWN",

    # ==========================================
    # Numpad
    # Verify names against your installed
    # adafruit_hid version if needed.
    # ==========================================
    "NUM0": "KEYPAD_ZERO",
    "NUM1": "KEYPAD_ONE",
    "NUM2": "KEYPAD_TWO",
    "NUM3": "KEYPAD_THREE",
    "NUM4": "KEYPAD_FOUR",
    "NUM5": "KEYPAD_FIVE",
    "NUM6": "KEYPAD_SIX",
    "NUM7": "KEYPAD_SEVEN",
    "NUM8": "KEYPAD_EIGHT",
    "NUM9": "KEYPAD_NINE",

    "NUM+": "KEYPAD_PLUS",
    "NUM-": "KEYPAD_MINUS",
    "NUM*": "KEYPAD_ASTERISK",
    "NUM/": "KEYPAD_FORWARD_SLASH",

    "NUM.": "KEYPAD_PERIOD",
    "NUMENTER": "KEYPAD_ENTER",
}

    if token in aliases:
        return aliases[token]

    if len(token) == 1 and token.isalpha():
        return token

    if token.isdigit():
        digit_names = {
            "0": "ZERO",
            "1": "ONE",
            "2": "TWO",
            "3": "THREE",
            "4": "FOUR",
            "5": "FIVE",
            "6": "SIX",
            "7": "SEVEN",
            "8": "EIGHT",
            "9": "NINE",
        }
        return digit_names[token]

    return token


def token_to_keycode(token):
    token = normalize_token(token)
    if hasattr(Keycode, token):
        return getattr(Keycode, token)
    return None


def send_consumer_action(action_text):
    upper = action_text.strip().upper()

    if upper in ("VOLUME_UP", "VOLUME_INCREMENT"):
        consumer.send(ConsumerControlCode.VOLUME_INCREMENT)
        return True

    if upper in ("VOLUME_DOWN", "VOLUME_DECREMENT"):
        consumer.send(ConsumerControlCode.VOLUME_DECREMENT)
        return True

    return False


def execute_shortcut(action_text):
    parts = [p.strip() for p in action_text.split("+") if p.strip()]
    if not parts:
        print("Empty action")
        return False

    codes = []
    for part in parts:
        code = token_to_keycode(part)
        if code is None:
            print("Unknown token:", part, "in", action_text)
            return False
        codes.append(code)

    keyboard.send(*codes)
    return True


def execute_hold(action_text):
    text = action_text.strip()
    upper = text.upper()

    if not upper.startswith("HOLD(") or not text.endswith(")"):
        return False

    inner = text[5:-1].strip()
    if "," not in inner:
        print("Bad HOLD syntax:", action_text)
        return False

    key_spec, duration_text = inner.rsplit(",", 1)
    key_spec = key_spec.strip()
    duration_text = duration_text.strip()

    try:
        duration_ms = int(duration_text)
    except ValueError:
        print("Bad HOLD duration:", action_text)
        return False

    if duration_ms < 0:
        print("Bad HOLD duration:", action_text)
        return False

    key_parts = [p.strip() for p in key_spec.split("+") if p.strip()]
    if not key_parts:
        print("Bad HOLD key spec:", action_text)
        return False

    codes = []
    for part in key_parts:
        code = token_to_keycode(part)
        if code is None:
            print("Unknown token in HOLD:", part, "in", action_text)
            return False
        codes.append(code)

    try:
        keyboard.press(*codes)
        time.sleep(duration_ms / 1000.0)
    finally:
        keyboard.release_all()

    return True


def get_map_label(profile, key_name, fallback_text):
    if profile is None:
        return fallback_text

    label_key = key_name + "_LABEL"
    label_text = profile["bindings"].get(label_key, "").strip()
    if label_text:
        return label_text

    return fallback_text


def execute_action(action_text):
    action = action_text.strip()
    upper = action.upper()

    if upper == "PROFILE_NEXT":
        step_profile(1)
        show_temporary("Profile next")
        return

    if upper == "PROFILE_PREV":
        step_profile(-1)
        show_temporary("Profile prev")
        return

    if upper.startswith("HOLD("):
        if execute_hold(action):
            show_temporary(action)
        return

    if send_consumer_action(action):
        show_temporary(action)
        return

    if execute_shortcut(action):
        show_temporary(action)


# =================================================
# Map loading
# =================================================

def load_keymap_list():
    try:
        names = os.listdir(KEYMAP_DIR)
    except OSError as exc:
        print("Could not open KeyMaps folder:", exc)
        return []

    files = []
    for name in names:
        if name.lower().endswith(".map"):
            files.append(KEYMAP_DIR + "/" + name)

    files.sort()
    return files


def load_keymap(path):
    profile_name = None
    bindings = {}

    with open(path, "r") as fp:
        for raw in fp:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue

            if profile_name is None:
                profile_name = line
                continue

            if "=" not in line:
                print("Ignoring line:", line)
                continue

            key, value = line.split("=", 1)
            key = key.strip().upper()
            value = value.strip()
            bindings[key] = value

    if profile_name is None:
        profile_name = path.split("/")[-1]

    return {
        "path": path,
        "name": profile_name,
        "bindings": bindings,
    }


def current_profile():
    if active_index is None or not profiles:
        return None
    if active_index < 0 or active_index >= len(profiles):
        return None
    return profiles[active_index]


def current_profile_name():
    profile = current_profile()
    if profile is None:
        return "No Profiles"
    return profile["name"]


def reload_profiles():
    global profiles, active_index, menu_index

    profiles = []
    for path in load_keymap_list():
        profile = load_keymap(path)
        profiles.append(profile)
        print("Loaded profile:", profile["name"], "from", profile["path"])
        for k, v in profile["bindings"].items():
            print(" ", k, "=", v)

    active_index = 0 if profiles else None

    if last_profile_name and profiles:
        for i, profile in enumerate(profiles):
            if profile["name"] == last_profile_name:
                active_index = i
                break

    menu_index = 0
    redraw()


# =================================================
# Menu helpers
# =================================================

def build_root_menu_items():
    items = []
    for i, profile in enumerate(profiles):
        items.append(
            {
                "kind": "profile",
                "label": profile["name"],
                "profile_index": i,
            }
        )

    items.append(
        {
            "kind": "settings",
            "label": "Settings",
        }
    )

    return items


def build_settings_menu_items():
    return [
        {
            "kind": "reload",
            "label": "Reload Profiles",
        },
        {
            "kind": "keytest",
            "label": "Key Test",
        },
        {
            "kind": "about",
            "label": "About",
        },
        {
            "kind": "back",
            "label": "Back",
        },
    ]


def current_menu_items():
    if menu_level == "settings":
        return build_settings_menu_items()
    if menu_level == "about":
        return []
    if menu_level == "keytest":
        return []
    return build_root_menu_items()


def current_menu_item():
    items = current_menu_items()
    if not items:
        return None
    return items[menu_index % len(items)]


def visible_window(items, selected, visible_count):
    if not items:
        return 0, []

    if len(items) <= visible_count:
        return 0, items[:]

    cursor_row = visible_count // 2
    start = selected - cursor_row

    if start < 0:
        start = 0

    if start > len(items) - visible_count:
        start = len(items) - visible_count

    return start, items[start:start + visible_count]


def redraw():
    if menu_mode:
        clear_all_labels()

        if menu_level == "root":
            menu_title.text = ""
            set_root_row_layout()

            items = current_menu_items()
            rows = [menu_line1, menu_line2, menu_line3]
            for row in rows:
                row.text = ""

            if not items:
                menu_line1.text = "No items"
                return

            start, window = visible_window(items, menu_index, 3)
            for i, item in enumerate(window):
                absolute_index = start + i
                prefix = "> " if absolute_index == menu_index else "  "
                rows[i].text = prefix + item["label"][:16]

        elif menu_level == "settings":
            menu_title.text = "Settings"
            set_titled_row_layout()

            items = current_menu_items()
            rows = [menu_line1, menu_line2, menu_line3]
            for row in rows:
                row.text = ""

            if not items:
                menu_line1.text = "No items"
                return

            start, window = visible_window(items, menu_index, 3)
            for i, item in enumerate(window):
                absolute_index = start + i
                prefix = "> " if absolute_index == menu_index else "  "
                rows[i].text = prefix + item["label"][:16]

        elif menu_level == "about":
            menu_title.text = "About"
            set_titled_row_layout()

            cp_version = "{}.{}.{}".format(*sys.implementation.version[:3])
            menu_line1.text = "FW " + FW_VERSION
            menu_line2.text = "CP " + cp_version
            menu_line3.text = "Profiles " + str(len(profiles))

        elif menu_level == "keytest":
            menu_title.text = "Key Test"
            set_titled_row_layout()
            menu_line1.text = keytest_last_event[:16]
            menu_line2.text = keytest_exit_hint[:16]
            menu_line3.text = ""

    else:
        clear_all_labels()
        main_title.text = current_profile_name()[:8]
        main_status.text = default_status


def step_profile(delta):
    global active_index, menu_index
    if not profiles:
        return

    if active_index is None:
        active_index = 0

    active_index = (active_index + delta) % len(profiles)
    menu_index = active_index
    print("Active profile:", current_profile_name())
    persist_last_profile()
    redraw()


def enter_menu():
    global menu_mode, menu_level, menu_index
    menu_mode = True
    menu_level = "root"

    items = current_menu_items()
    if not items:
        menu_index = 0
    else:
        if active_index is None:
            menu_index = len(items) - 1
        else:
            menu_index = min(active_index, len(items) - 1)

    print("Menu mode")
    redraw()


def apply_root_selection():
    global menu_mode, menu_level, active_index, menu_index

    item = current_menu_item()
    if item is None:
        return

    if item["kind"] == "profile":
        active_index = item["profile_index"]
        print("Applied profile:", current_profile_name())
        persist_last_profile()
        menu_mode = False
        menu_level = "root"
        redraw()
        return

    if item["kind"] == "settings":
        menu_level = "settings"
        menu_index = 0
        print("Settings menu")
        redraw()
        return


def apply_settings_selection():
    global menu_level, menu_index

    item = current_menu_item()
    if item is None:
        return

    kind = item["kind"]

    if kind == "reload":
        reload_profiles()
        menu_level = "settings"
        menu_index = 0
        print("Profiles reloaded")
        redraw()
        return

    if kind == "keytest":
        menu_level = "keytest"
        menu_index = 0
        print("Key Test")
        redraw()
        return

    if kind == "about":
        menu_level = "about"
        menu_index = 0
        redraw()
        return

    if kind == "back":
        menu_level = "root"
        menu_index = active_index if active_index is not None else 0
        print("Back to profiles")
        redraw()
        return


# =================================================
# Inputs
# =================================================

def make_button(pin):
    io = digitalio.DigitalInOut(pin)
    io.direction = digitalio.Direction.INPUT
    io.pull = digitalio.Pull.UP
    return Debouncer(io)


encoder_push = make_button(board.GP4)

buttons = {
    "K1": make_button(board.GP5),
    "K2": make_button(board.GP6),
    "K3": make_button(board.GP7),
    "K4": make_button(board.GP8),
    "K5": make_button(board.GP9),
    "K6": make_button(board.GP10),
    "K7": make_button(board.GP11),
    "K8": make_button(board.GP12),
    "K9": make_button(board.GP13),
    "K10": make_button(board.GP14),
    "K11": make_button(board.GP15),
    "K12": make_button(board.GP16),
}

encoder = rotaryio.IncrementalEncoder(board.GP2, board.GP3)
last_encoder_pos = encoder.position


# =================================================
# Startup
# =================================================


#show_splash()

load_status()
reload_profiles()

if not profiles:
    main_title.text = "KeyMaps"
    main_status.text = "No .map files"
    print("No .map files found in KeyMaps/")

redraw()
print("Active profile:", current_profile_name())

# =================================================
# Main loop
# =================================================

while True:
    encoder_push.update()

    if menu_level == "keytest":
        for name, button in buttons.items():
            button.update()
            if button.fell:
                keytest_last_event = name
                print("Key test:", name)
                note_activity()
                wake_display()
                redraw()

    else:
        for name, button in buttons.items():
            button.update()

            if button.fell and not menu_mode:
                note_activity()
                wake_display()

                profile = current_profile()
                if profile is None:
                    show_temporary("No profile")
                    continue

                action = profile["bindings"].get(name)
                if action:
                    print(name, "->", action)
                    execute_action(action)
                    display_text = get_map_label(profile, name, action)
                    show_temporary(display_text)
                else:
                    print(name, "unmapped")
                    show_temporary(name + " unmapped")

    if encoder_push.fell:
        note_activity()
        wake_display()

        if menu_level == "keytest":
            menu_level = "settings"
            menu_index = 1
            redraw()
        elif menu_mode:
            if menu_level == "root":
                apply_root_selection()
            elif menu_level == "settings":
                apply_settings_selection()
            elif menu_level == "about":
                menu_level = "settings"
                menu_index = 2
                redraw()
        else:
            enter_menu()

    pos = encoder.position
    if pos != last_encoder_pos:
        note_activity()
        wake_display()

        if menu_level == "keytest":
            if pos > last_encoder_pos:
                keytest_last_event = "ENC CW"
            else:
                keytest_last_event = "ENC CCW"
            print("Key test:", keytest_last_event)
            redraw()

        elif menu_mode:
            if menu_level in ("root", "settings"):
                items = current_menu_items()
                if items:
                    if pos > last_encoder_pos:
                        menu_index = (menu_index + 1) % len(items)
                    else:
                        menu_index = (menu_index - 1) % len(items)

                    item = current_menu_item()
                    if item is not None:
                        print("Menu item:", item["label"])
                    redraw()

        else:
            profile = current_profile()
            if profile is not None:
                key_name = "ENC_CW" if pos > last_encoder_pos else "ENC_CCW"
                action = profile["bindings"].get(key_name)

                if action:
                    print("ENC ->", action)
                    execute_action(action)
                    display_text = get_map_label(profile, key_name, action)
                    show_temporary(display_text)
                else:
                    show_temporary("ENC unmapped")

        last_encoder_pos = pos

    if status_until and not menu_mode and menu_level != "keytest" and time.monotonic() > status_until:
        redraw()
        status_until = 0.0

    sleep_display_if_idle()
    time.sleep(0.01)

import time
import board
import digitalio
import storage
import supervisor

supervisor.set_usb_identification(
    manufacturer="MacioMan",
    product="MACROPAD",
)

# Hold encoder push (GP4) during boot to enter maintenance mode.
button = digitalio.DigitalInOut(board.GP4)
button.switch_to_input(pull=digitalio.Pull.UP)

button_pressed = False
start_time = time.monotonic()

# Give yourself a short window to press and hold the encoder switch.
while time.monotonic() - start_time < 2.0:
    if not button.value:  # active-low
        button_pressed = True
        break
    time.sleep(0.05)

if button_pressed:
    storage.enable_usb_drive()
    storage.remount("/", readonly=True)
    print("Maintenance mode: USB drive enabled.")
else:
    storage.disable_usb_drive()
    storage.remount("/", readonly=False)
    print("Normal mode: USB drive disabled.")